const express = require("express");
require("../src/db/conn");

const MensRanking = require("../src/models/mens");

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
/* insert data with using json data through postman */
app.post("/mens", async (req, res)=>{
    try{
        const addingrecord = new MensRanking(req.body)
        console.log(req.body);
        const insrtMens = await addingrecord.save();
        res.status(201).send(insrtMens);
    }catch(e){
        res.status(400).send(e);
    }
})
/* show data with postman */

app.get("/mens", async (req, res)=>{
    try{
        const getMens = await MensRanking.find({}).sort({"ranking":1});
        res.send(getMens);
    }catch(e){
        res.status(400).send(e);
    }
})

/* find indeviual value in data base */
app.get("/mens/:id", async (req, res)=>{
    try{
        const _id = req.params.id;  
        const getMen = await MensRanking.findById({_id});
        res.send(getMen);
    }catch(e){
        res.status(400).send(e);
    }
})

/* update my data using id  */
app.patch("/mens/:id", async (req, res)=>{
    try{
        const _id = req.params.id;  
        const getMen = await MensRanking.findByIdAndUpdate(_id , req.body, {
            new:true
        });
        res.send(getMen);
    }catch(e){
        res.status(500).send(e);
    }
})
/* delete method using postman*/
app.delete("/mens/:id", async (req, res)=>{
    try{
        const _id = req.params.id;  
        const getMen = await MensRanking.findByIdAndDelete(req.params.id);
        res.send(getMen);
    }catch(e){
        res.status(500).send(e);
    }
})



app.get("/",async (req,res) =>{
    res.send(`<h1>hello i am running server</h1>`);
})
app.listen(port, () =>{
    console.log(`connection is live at port no ${port}`);

})